﻿namespace Family.Authentication
{
    public class UserAccount
    {
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public string? Role { get; set; }

        // Манипуляции с выборками
        public string? focusId { get; set; }
        //public 

        public UserAccount() { }
    }
}
